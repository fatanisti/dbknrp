<?php

namespace App\Http\Controllers;

use App\Donatur;
use App\Riwayat;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class DonaturController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $entry = [
            'keywordDaerah' => $request->keywordDaerah,
        ];

        $donatur = Donatur::with('user')
            ->join('users', 'donatur.user_id', '=', 'users.id')
            ->where('users.role', 5)
            ->orderBy('users.nama', 'asc')
            ->when($request->keywordDaerah != null, function ($query) use ($request) {
                $query->where('donatur.kota_kab', $request->keywordDaerah);
            })->paginate(5);

        $donatur->appends($request->only('keywordDaerah', 'limit'));

        return view('maintable', compact('donatur', 'entry'));

        // Versi 2
        // $donatur = Donatur::with('user')
        //     ->join('users', 'donatur.user_id', '=', 'users.id')
        //     ->orderBy('users.nama', 'asc')
        //     ->paginate(5);
        
        // Versi 1
        // $data = DB::table('users')
        //     ->join('donatur', 'users.id', '=', 'donatur.user_id')            
        //     ->select('users.nama', 'users.nama', 'donatur.kab_kota', 'donatur.no_hp')
        //     ->get();

        // return view ('maintable', ['donatur'=>$donatur]);
    }

    function random_username($string) {
        $pattern = " ";
        $firstPart = strstr(strtolower($string), $pattern, true);
        $secondPart = substr(strstr(strtolower($string), $pattern, false), 0,3);
        $nrRand = rand(1, 1000);
        
        $username = trim($firstPart).trim($secondPart).trim($nrRand);
        return $username;
    }

    function random_string($length = 10) {
        return substr(str_shuffle(
            "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {        
        $entry = [
            'inputIDDon' => $request->inputIDDon,
            'inputTglReg' => $request->inputTglReg,
            'inputNama' => $request->inputNama,
            'inputBP' => $request->inputBP,
            'inputBOD' => $request->inputBOD,
            'inputAddress' => $request->inputAddress,
            'inputRT' => $request->inputRT,
            'inputRW' => $request->inputRW,
            'inputKodepos' => $request->inputKodepos,
            'inputKel' => $request->inputKel,
            'inputKec' => $request->inputKec,
            'inputKab' => $request->inputKab,
            'inputProv' => $request->inputProv,
            'inputNegara' => $request->inputNegara,
            'inputTelp' => $request->inputTelp,
            'inputHP' => $request->inputHP,
            'inputEmail' => $request->inputEmail,
            'inputProf' => $request->inputProf,
            'inputFB' => $request->inputFB,
            'inputIG' => $request->inputIG,
            'inputDona' => $request->inputDona,
            'inputJenis' => $request->inputJenis,
            'inputCatatan' => $request->inputCatatan,
        ];

        return view('createdona', compact('entry'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request);
        
        $generateuser = $this->random_username($request->inputNama);
        $generatepass = $this->random_string();

        $akun = [
            'username' => $generateuser,
            'password' => $generatepass,
        ];
        
        $user = new User();

        $user->nama = $request->inputNama;
        $user->no_id = $request->inputIDDon;
        $user->tgl_regis = $request->inputTglReg;
        $user->username = $generateuser;
        $user->password = Hash::make($generatepass);
        $user->role = '5';
        $user->save();

        $donatur = new Donatur;
        
        $donatur->tempat_lahir = $request->inputBP;
        $donatur->tgl_lahir = $request->inputBOD;
        $donatur->alamat = $request->inputAddress;
        $donatur->rt = $request->inputRT;
        $donatur->rw = $request->inputRW;
        $donatur->kodepos = $request->inputKodepos;
        $donatur->kelurahan = $request->inputKel;
        $donatur->kecamatan = $request->inputKec;
        $donatur->kota_kab = $request->inputKab;
        $donatur->provinsi = $request->inputProv;
        $donatur->negara = $request->inputNegara;
        $donatur->no_telp = $request->inputTelp;
        $donatur->no_hp = $request->inputHP;
        $donatur->email = $request->inputEmail;
        $donatur->profesi = $request->inputProf;
        $donatur->akun_facebook = $request->inputFB;
        $donatur->akun_instagram = $request->inputIG;
        $donatur->catatan = $request->inputCatatan;
        $donatur->user_id = $user->id;
        // dd($donatur);
        $donatur->save();

        $riwayat = new Riwayat;

        $riwayat->tanggal = $request->inputTglReg;
        $riwayat->dona_jml = $request->inputDona;
        $riwayat->dona_jenis = $request->inputJenis;
        $riwayat->bank = 'Donasi Perdana';
        $riwayat->bank_petugas = 'Fulan';
        $riwayat->user_id = $user->id;
        $riwayat->save();

        return redirect()->action(
            'DonaturController@giveacc', $akun
        );
    }

    public function giveacc(Request $request){
        return view ('storedona', compact('request'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Donatur  $donatur
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $donatur = Donatur::with('user')->where('user_id',$id)->first();
        
        // $data = DB::table('users')
        //     ->join('donatur', 'users.id', '=', 'donatur.user_id')            
        //     ->select('users.nama', 'users.nama', 'donatur.kab_kota', 'donatur.no_hp')
        //     ->get();

        return view ('donadata', ['donatur'=>$donatur]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Donatur  $donatur
     * @return \Illuminate\Http\Response
     */
    public function edit(Donatur $donatur)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Donatur  $donatur
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Donatur $donatur)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Donatur  $donatur
     * @return \Illuminate\Http\Response
     */
    public function destroy(Donatur $donatur)
    {
        //
    }
}
