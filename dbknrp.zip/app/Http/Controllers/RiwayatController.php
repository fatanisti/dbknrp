<?php

namespace App\Http\Controllers;

use App\Donatur;
use App\Riwayat;
use Illuminate\Http\Request;

class RiwayatController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = $request->get('q');

        $keywordNama = $request->keywordNama;
        $keywordDaerah = $request->keywordDaerah;

        $entry = [
            'keywordNama' =>$keywordNama,
            'keywordDaerah' =>$keywordDaerah,
        ];

        $donatur = Donatur::with('user')
            ->join('users', 'donatur.user_id', '=', 'users.id')
            ->orderBy('users.nama', 'asc')
            ->where('users.role', 5)
            ->when($request->keywordNama != null, function ($query) use ($request) {
                $query->where('users.nama', 'like', "%{$request->keywordNama}%");})
            ->when($request->keywordDaerah != null, function ($query) use ($request) {
                $query->where('donatur.kota_kab', $request->keywordDaerah);})    
            ->paginate(5);

        return view('maintable', compact('donatur', 'query', 'entry'));

        // Versi 2
        // $this->validate($request, [
        //     'limit' => 'integer',
        // ]);

        // $donatur = Donatur::with('user')
        //     ->join('users', 'donatur.user_id', '=', 'users.id')
        //     ->orderBy('users.nama', 'asc')
        //     ->when($request->keywordNama, function ($query) use ($request) {
        //         $query->where('users.nama', 'like', "%{$request->keywordNama}%");
        //     })->paginate($request->limit ? $request->limit : 5);

        // $donatur->appends($request->only('keywordNama', 'limit'));

        // return view('maintable', compact('donatur'));

        // Versi 1
        // $donatur = Donatur::with('user')
        //     ->join('users', 'donatur.user_id', '=', 'users.id')
        //     ->orderBy('users.nama', 'asc')
        //     ->paginate(5);

        // return view ('maintable', ['donatur'=>$donatur]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Riwayat  $riwayat
     * @return \Illuminate\Http\Response
     */
    public function show($id, Request $request)
    {
        $query = $request->get('q');
        
        $keywordBulan = $request->keywordBulan;
        $keywordTahun = $request->keywordTahun;

        $entry = [
            'keywordBulan' => $keywordBulan,
            'keywordTahun' => $keywordTahun,
        ];

        $donatur = Donatur::with('user')->where('user_id',$id)->first();
        $riwayat = Riwayat::with('user')->where('user_id',$donatur->user_id)
            ->orderBy('tanggal', 'asc')
            ->where('users.role', 5)
            ->when($request->keywordBulan != null, function ($query) use ($request) {
                $query->whereMonth('tanggal', $request->keywordBulan);})
            ->when($request->keywordTahun != null, function ($query) use ($request) {
                $query->whereYear('tanggal', $request->keywordTahun);})
            ->paginate(5);

        $data = [
            'donatur' => $donatur,
            'riwayat' => $riwayat,
        ];

        return view('donariwa', $data, compact('entry'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Riwayat  $riwayat
     * @return \Illuminate\Http\Response
     */
    public function edit(Riwayat $riwayat)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Riwayat  $riwayat
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Riwayat $riwayat)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Riwayat  $riwayat
     * @return \Illuminate\Http\Response
     */
    public function destroy(Riwayat $riwayat)
    {
        //
    }
}
