<?php

namespace App\Http\Controllers;

use DB;
use App\Donatur;
use App\Riwayat;
use Illuminate\Http\Request;

class LaporanController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // dd(date('m'));
        // dd($request->all());
        $query = $request->get('q');

        $keywordDaerah = $request->keywordDaerah;
        $keywordBulan = $request->keywordBulan;
        $keywordTahun = $request->keywordTahun;
        $keywordBentuk = $request->keywordBentuk;

        $entry = [
            'keywordDaerah' =>$keywordDaerah,
            'keywordBulan' =>$keywordBulan,
            'keywordTahun' =>$keywordTahun,
            'keywordBentuk' =>$keywordBentuk,
        ];

        $result = DB::table('riwayat_donasi')
            ->join('donatur', 'donatur.user_id', '=', 'riwayat_donasi.user_id')
            ->join('users', 'users.id', '=', 'donatur.user_id')
            ->where('users.role', 5)
            ->when($request->keywordDaerah != null, function ($query) use ($request) {
                $query->where('donatur.kota_kab', $request->keywordDaerah)
            ;})
            ->when($request->keywordBulan != null, function ($query) use ($request) {
                $query->whereMonth('riwayat_donasi.tanggal', $request->keywordBulan)
            ;})
            ->when($request->keywordTahun != null, function ($query) use ($request) {
                $query->whereYear('riwayat_donasi.tanggal', $request->keywordTahun)
            ;})
            ->get();

        $result2 = DB::table('riwayat_donasi')
            ->join('donatur', 'donatur.user_id', '=', 'riwayat_donasi.user_id')
            ->join('users', 'users.id', '=', 'donatur.user_id')
            ->where('users.role', 5)
            ->when($request->keywordDaerah != null, function ($query) use ($request) {
                $query->where('donatur.kota_kab', $request->keywordDaerah)
            ;})
            ->when($request->keywordBulan != null, function ($query) use ($request) {
                $query->whereMonth('riwayat_donasi.tanggal', $request->keywordBulan)
            ;})
            ->when($request->keywordTahun != null, function ($query) use ($request) {
                $query->whereYear('riwayat_donasi.tanggal', $request->keywordTahun)
            ;})
            ->paginate(10);

        //  dd($result2->toArray());
        return view('laporan', compact('result', 'result2', 'query', 'entry', 'chart'));
        // return response()->json($result);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Laporan  $laporan
     * @return \Illuminate\Http\Response
     */
    public function show(Laporan $laporan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Laporan  $laporan
     * @return \Illuminate\Http\Response
     */
    public function edit(Laporan $laporan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Laporan  $laporan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Laporan $laporan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Laporan  $laporan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Laporan $laporan)
    {
        //
    }
}
