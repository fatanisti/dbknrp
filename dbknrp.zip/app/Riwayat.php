<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Riwayat extends Model
{
    protected $table = "riwayat_donasi";

    protected $fillable = [
        'tanggal',
        'dona_jml',
        'dona_jenis',
        'bank',
        'bank_petugas',
    ];

    public $timestamps = false;

    public function user()
    {
        return $this->belongsTo('App\User');
    }
}
