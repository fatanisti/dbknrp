@extends('home')

@section('pageTitle', 'Data Donatur')

@section('subcontent')
<div class="container">
    <div class="card">
        <div class="card-header"><h4>{{ __('PROFIL DONATUR') }}</h4></div>
        <div class="card-body">
            <div class="row">
                <div class="col-4"><h5>ID Donatur: </h5></div>
                <div class="col-8">{{ $donatur->user->no_id }}</div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Tanggal Registrasi: </h5></div>
                <div class="col-8">{{ $donatur->user->tgl_regis }}</div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Nama Lengkap: </h5></div>
                <div class="col-8">{{ $donatur->user->nama }}</div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Tempat Lahir: </h5></div>
                <div class="col-8">{{ $donatur->tempat_lahir }}</div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Tanggal Lahir: </h5></div>
                <div class="col-8">{{ $donatur->tgl_lahir }}</div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Alamat Domisili: </h5></div>
                <div class="col-8">{{ $donatur->alamat }} RT{{ $donatur->rt }}/RW{{ $donatur->rw }} {{ $donatur->kelurahan }}, {{ $donatur->kecamatan }}, {{ $donatur->kota_kab }}, {{ $donatur->provinsi }}, {{ $donatur->negara }} {{ $donatur->kodepos }}</div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Telepon/No. HP: </h5></div>
                <div class="col-8">{{ $donatur->no_telp }} / {{ $donatur->no_hp }}</div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Email: </h5></div>
                <div class="col-8">{{ $donatur->email }}</div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Facebook: </h5></div>
                <div class="col-8">{{ $donatur->akun_facebook }}</div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Instagram: </h5></div>
                <div class="col-8">{{ $donatur->akun_instagram }}</div>
            </div>
        </div>
    </div>
</div>
@endsection