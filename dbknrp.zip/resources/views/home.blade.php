@extends('app')

@section('pageTitle', 'Home')

@section('content')
<div class="container">
    <div class="header">
        <p>Selamat Datang, {{ Auth::user()->nama }}</p>
    </div>

    <div>
        <ul class="nav nav-pills nav-fill">
            @if ( Auth::user()->role === 2 || Auth::user()->role === 3 || Auth::user()->role === 4 )
            <li class="nav-item">
                <a class="nav-link" href="#">Input Donasi</a>
            </li>
            @endif
            <li class="nav-item">
            @if ( Auth::user()->role === 5)
                <a class="nav-link {{ Request::segment(1) === 'data_donatur' ? 'active' : null }}" href="/data_donatur/{{ auth()->id() }}">Data Donatur</a>
            @else
                <a class="nav-link {{ Request::segment(1) === 'data_donatur' ? 'active' : null }}" href="{{ route ('dona_data') }}">Data Donatur</a>
            @endif
            </li>
            <li class="nav-item">
            @if ( Auth::user()->role === 5)
                <a class="nav-link {{ Request::segment(1) === 'riwayat_donasi' ? 'active' : null }}" href="/riwayat_donasi/{{ auth()->id() }}">Riwayat Donasi</a>
            @else
                <a class="nav-link {{ Request::segment(1) === 'riwayat_donasi' ? 'active' : null }}" href="{{ route('dona_riwa') }}">Riwayat Donasi</a>
            @endif
            </li>
            @if ( Auth::user()->role === 5)
            @else
            <li class="nav-item">
                <a class="nav-link {{ Request::segment(1) === 'laporan' ? 'active' : null }}" href="{{ route('dona_laporan') }}">Laporan</a>
            </li>
            @endif
        </ul>
    </div>

    <div class="card">
        <div style="padding:30px 10px;">
        @if (Route::current()->getName() == 'home')
            <p>Website ini masih dalam tahap pengembangan</p>
        @else
            @yield('subcontent')
        @endif
        </div>
    </div>
</div>
@endsection