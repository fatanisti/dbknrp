<?php

use Faker\Generator as Faker;

$factory->define(App\Donatur::class, function (Faker $faker) {
    return [
        'tempat_lahir' => $faker->city,
        'tgl_lahir' => $faker->dateTimeThisCentury($max = 'now', $timezone = null),
        'alamat' => $faker->streetAddress,
        'rt' => $faker->randomDigitNotNull,
        'rw' => $faker->randomDigitNotNull,
        'kodepos' => $faker->postcode,
        'kota_kab' => $faker->randomElement(['Kab. Bandung', 'Kab. Sumedang', 'Kota Cimahi']),
        'provinsi' => 'Jawa Barat',
        'negara' => 'Indonesia',
        'no_telp' => $faker->phoneNumber,
        'no_hp' => $faker->phoneNumber,
        'email' => $faker->unique()->safeEmail,
        'akun_facebook' => $faker->userName,
        'akun_instagram' => $faker->userName,
        'profesi' => $faker->company,
        'catatan' => $faker->word,
    ];
});
