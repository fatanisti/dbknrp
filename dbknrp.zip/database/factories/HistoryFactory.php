<?php

use Faker\Generator as Faker;

$factory->define(App\Riwayat::class, function (Faker $faker) {
    return [
        'tanggal' => $faker->dateTimeThisYear($max = 'now', $timezone = null),
        'dona_jml' => $faker->randomNumber,
        'dona_jenis' => $faker->randomElement(['Cash', 'Transfer']),
        'bank' => $faker->randomElement(['BNI', 'BCA', 'Mandiri', 'CIMB', 'BRI']),
        'bank_petugas' => $faker->name,
    ];
});