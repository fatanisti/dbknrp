<?php

use Illuminate\Database\Seeder;

class ProfileSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\User::class, 20)
        ->create()
        ->each(function ($user) {
            $user->donatur()->save(factory(App\Donatur::class)->make());
            $user->riwayat()->saveMany(factory(App\Riwayat::class, 10)->make());
        });
    }
}
