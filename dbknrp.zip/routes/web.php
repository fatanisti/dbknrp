<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Auth::routes();

Route::get('/', function () {
    if(Auth::check()) {
        return redirect()->route('home');
    }
    return view('landing');
});

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/data_donatur', 'DonaturController@index')->name('dona_data');
Route::get('/data_donatur/{id}', 'DonaturController@show')->name('donatur/{id}');
Route::get('/laporan', 'LaporanController@index')->name('dona_laporan');
Route::get('/riwayat_donasi', 'RiwayatController@index')->name('dona_riwa');
Route::get('/riwayat_donasi/{id}', 'RiwayatController@show')->name('riwayat/{id}');
Route::get('/tambah_donatur', 'DonaturController@create')->name('create_dona');
Route::get('/tambah_donatur_sukses', 'DonaturController@giveacc')->name('give_acc');
Route::post('/simpan_donatur', 'DonaturController@store')->name('store_dona');
