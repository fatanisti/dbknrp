<?php $__env->startSection('pageTitle', 'Akun Donatur Baru'); ?>

<?php $__env->startSection('subcontent'); ?>
<div class="card">
    <div class="card-body">
        <h5 class="card-title">AKUN DONATUR BERHASIL DITAMBAHKAN</h5>
        <p class="card-text">Mohon untuk mencatat <b>Username</b> dan <b>Password</b> di bawah ini untuk diberikan kepada donatur terkait.</p>
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">Username : <b><?php echo e($request->username); ?></b></li>
        <li class="list-group-item">Password : <b><?php echo e($request->password); ?></b></li>
    </ul>
    <div class="card-body">
        <a href="<?php echo e(route('dona_data')); ?>" class="card-link">Kembali</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>