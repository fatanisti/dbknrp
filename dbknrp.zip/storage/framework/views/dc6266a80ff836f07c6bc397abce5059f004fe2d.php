<?php if(Route::current()->getName() == 'dona_data'): ?>
    <?php $__env->startSection('pageTitle', 'Data Donatur'); ?>
<?php else: ?>
    <?php $__env->startSection('pageTitle', 'Riwayat Donasi'); ?>
<?php endif; ?>

<?php $__env->startSection('subcontent'); ?>
<div class="container">
    <form action="<?php echo e(url()->current()); ?>" style="padding: 0px 0px 10px 0px;">
        <div class="form-group" method="GET">
            <label for="daerah">Daerah</label>
            <select class="form-control" id="daerah" name="keywordDaerah">
                <option value="">--- Semua ---</option>
                <option value="Kab. Bandung" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Bandung' ? 'selected' : ''); ?>>Kab. Bandung</option>
                <option value="Kab. Bandung Barat" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Bandung Barat' ? 'selected' : ''); ?>>Kab. Bandung Barat</option>
                <option value="Kab. Bekasi" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Bekasi' ? 'selected' : ''); ?>>Kab. Bekasi</option>
                <option value="Kab. Ciamis" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Ciamis' ? 'selected' : ''); ?>>Kab. Ciamis</option>
                <option value="Kab. Cianjur" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Cianjur' ? 'selected' : ''); ?>>Kab. Cianjur</option>
                <option value="Kab. Cirebon" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Cirebon' ? 'selected' : ''); ?>>Kab. Cirebon</option>
                <option value="Kab. Garut" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Garut' ? 'selected' : ''); ?>>Kab. Garut</option>
                <option value="Kab. Indramayu" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Indramayu' ? 'selected' : ''); ?>>Kab. Indramayu</option>
                <option value="Kab. Karawang" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Karawang' ? 'selected' : ''); ?>>Kab. Karawang</option>
                <option value="Kab. Kuningan" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Kuningan' ? 'selected' : ''); ?>>Kab. Kuningan</option>
                <option value="Kab. Majalengka" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Majalengka' ? 'selected' : ''); ?>>Kab. Majalengka</option>
                <option value="Kab. Pangandaran" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Pangandaran' ? 'selected' : ''); ?>>Kab. Pangandaran</option>
                <option value="Kab. Purwakarta" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Purwakarta' ? 'selected' : ''); ?>>Kab. Purwakarta</option>
                <option value="Kab. Subang" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Subang' ? 'selected' : ''); ?>>Kab. Subang</option>
                <option value="Kab. Sukabumi" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Sukabumi' ? 'selected' : ''); ?>>Kab. Sukabumi</option>
                <option value="Kab. Sumedang" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Sumedang' ? 'selected' : ''); ?>>Kab. Sumedang</option>
                <option value="Kab. Tasikmalaya" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kab. Tasikmalaya' ? 'selected' : ''); ?>>Kab. Tasikmalaya</option>
                <option value="Kota Bandung" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kota Bandung' ? 'selected' : ''); ?>>Kota Bandung</option>
                <option value="Kota Banjar" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kota Banjar' ? 'selected' : ''); ?>>Kota Banjar</option>
                <option value="Kota Bekasi" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kota Bekasi' ? 'selected' : ''); ?>>Kota Bekasi</option>
                <option value="Kota Bogor" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kota Bogor' ? 'selected' : ''); ?>>Kota Bogor</option>
                <option value="Kota Cimahi" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kota Cimahi' ? 'selected' : ''); ?>>Kota Cimahi</option>
                <option value="Kota Cirebon" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kota Cirebon' ? 'selected' : ''); ?>>Kota Cirebon</option>
                <option value="Kota Depok" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kota Depok' ? 'selected' : ''); ?>>Kota Depok</option>
                <option value="Kota Sukabumi" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kota Sukabumi' ? 'selected' : ''); ?>>Kota Sukabumi</option>
                <option value="Kota Tasikmalaya" <?php echo e(old('keywordDaerah', $entry['keywordDaerah'] )== 'Kota Tasikmalaya' ? 'selected' : ''); ?>>Kota Tasikmalaya</option>
            </select>
        </div>
    <?php if(Route::current()->getName() == 'dona_riwa'): ?>
        <div class="form-group">
            <label for="cariNama">Cari Nama</label>
            <input type="text" name="keywordNama" class="form-control" id="cariNama" placeholder="Masukan nama yang ingin dicari..." value="<?php echo e(old('keywordNama', $entry['keywordNama'])); ?>">
        </div>
    <?php endif; ?>
        <button type="submit" class="btn btn-primary">Cari</button>
    <?php if( Auth::user()->role === 3 || Auth::user()->role === 4): ?>
        <a href="<?php echo e(route('create_dona')); ?>" role="button" class="btn btn-warning offset-10">Tambah Data Donatur</a>
    <?php endif; ?>
    </form>
    <div class="row">
        <table class="table table-hover" id="tabel_data">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Daerah</th>
                    <th>No. HP</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $donatur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($donat->user->nama); ?></td>
                    <td><?php echo e($donat->kota_kab); ?></td>
                    <td><?php echo e($donat->no_hp); ?></td>
                <?php if(Route::current()->getName() == 'dona_data'): ?>
                    <td><a href="/data_donatur/<?php echo e($donat->user_id); ?>" class="btn btn-primary" style="width: 100%;">Profil</a></td>
                <?php else: ?>
                    <td><a href="/riwayat_donasi/<?php echo e($donat->user_id); ?>" class="btn btn-success" style="width: 100%;">Riwayat</a></td>
                <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <center><?php echo e($donatur->links()); ?></center>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>