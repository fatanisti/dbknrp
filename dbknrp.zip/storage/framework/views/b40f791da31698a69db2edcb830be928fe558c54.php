<?php $__env->startSection('pageTitle', 'Input Data Donatur'); ?>

<?php $__env->startSection('subcontent'); ?>
<div class="card">
    <div class="card-header">TAMBAH DONATUR</div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('store_dona')); ?>">
        <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group col-3">
                    <label for="inputIDDon">ID Donatur</label>
                    <input type="text" class="form-control" id="inputIDDon" name="inputIDDon" placeholder="Misal, 1293883994901...">
                </div>
                <div class="form-group col-2">
                    <label for="inputTglReg">Tanggal Registrasi</label>
                    <input type="date" class="form-control" id="inputTglReg" name="inputTglReg">
                </div>
                <div class="form-group col-7">
                    <label for="inputNama">Nama Lengkap</label>
                    <input type="text" class="form-control" id="inputNama" name="inputNama" placeholder="Nama Lengkap...">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-9">
                    <div class="form-row">
                        <div class="form-group col-8">
                            <label for="inputBP">Tempat Lahir</label>
                            <input type="text" class="form-control" id="inputBP" name="inputBP" placeholder="Nama Kota/Kab...">
                        </div>
                        <div class="form-group col-4">
                            <label for="inputBOD">Tanggal Lahir</label>
                            <input type="date" class="form-control" id="inputBOD" name="inputBOD">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-12">
                            <label for="inputAddress">Alamat Domisili</label>
                            <input type="text" class="form-control" id="inputAddress" name="inputAddress" placeholder="Masukkan nama jalan di sini...">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-1">
                            <label for="inputRT">RT</label>
                            <input type="text" class="form-control" id="inputRT" name="inputRT">
                        </div>
                        <div class="form-group col-1">
                            <label for="inputRW">RW</label>
                            <input type="text" class="form-control" id="inputRW" name="inputRW">
                        </div>
                        <div class="form-group col-2">
                            <label for="inputKodepos">Kodepos</label>
                            <input type="text" class="form-control" id="inputKodepos" name="inputKodepos">
                        </div>
                        <div class="form-group col-4">
                            <label for="inputKel">Kelurahan</label>
                            <input type="text" class="form-control" id="inputKel" name="inputKel">
                        </div>
                        <div class="form-group col-4">
                            <label for="inputKec">Kecamatan</label>
                            <input type="text" class="form-control" id="inputKec" name="inputKec">
                        </div>
                    </div>
                </div>
                <div class="form-group col-3">
                    <center><img src="<?php echo e(asset('icon/logo2.jpeg')); ?>" style="max-width:100%; max-height:100%;"></center>
                </div>
            </div>    
            <div class="form-row">
                <div class="form-group col-4">
                    <label for="inputKab">Kota/Kab</label>
                    <select class="form-control" id="inputKab" name="inputKab">
                        <option value="Kab. Bandung" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Bandung' ? 'selected' : ''); ?>>Kab. Bandung</option>
                        <option value="Kab. Bandung Barat" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Bandung Barat' ? 'selected' : ''); ?>>Kab. Bandung Barat</option>
                        <option value="Kab. Bekasi" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Bekasi' ? 'selected' : ''); ?>>Kab. Bekasi</option>
                        <option value="Kab. Ciamis" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Ciamis' ? 'selected' : ''); ?>>Kab. Ciamis</option>
                        <option value="Kab. Cianjur" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Cianjur' ? 'selected' : ''); ?>>Kab. Cianjur</option>
                        <option value="Kab. Cirebon" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Cirebon' ? 'selected' : ''); ?>>Kab. Cirebon</option>
                        <option value="Kab. Garut" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Garut' ? 'selected' : ''); ?>>Kab. Garut</option>
                        <option value="Kab. Indramayu" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Indramayu' ? 'selected' : ''); ?>>Kab. Indramayu</option>
                        <option value="Kab. Karawang" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Karawang' ? 'selected' : ''); ?>>Kab. Karawang</option>
                        <option value="Kab. Kuningan" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Kuningan' ? 'selected' : ''); ?>>Kab. Kuningan</option>
                        <option value="Kab. Majalengka" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Majalengka' ? 'selected' : ''); ?>>Kab. Majalengka</option>
                        <option value="Kab. Pangandaran" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Pangandaran' ? 'selected' : ''); ?>>Kab. Pangandaran</option>
                        <option value="Kab. Purwakarta" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Purwakarta' ? 'selected' : ''); ?>>Kab. Purwakarta</option>
                        <option value="Kab. Subang" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Subang' ? 'selected' : ''); ?>>Kab. Subang</option>
                        <option value="Kab. Sukabumi" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Sukabumi' ? 'selected' : ''); ?>>Kab. Sukabumi</option>
                        <option value="Kab. Sumedang" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Sumedang' ? 'selected' : ''); ?>>Kab. Sumedang</option>
                        <option value="Kab. Tasikmalaya" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kab. Tasikmalaya' ? 'selected' : ''); ?>>Kab. Tasikmalaya</option>
                        <option value="Kota Bandung" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kota Bandung' ? 'selected' : ''); ?>>Kota Bandung</option>
                        <option value="Kota Banjar" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kota Banjar' ? 'selected' : ''); ?>>Kota Banjar</option>
                        <option value="Kota Bekasi" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kota Bekasi' ? 'selected' : ''); ?>>Kota Bekasi</option>
                        <option value="Kota Bogor" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kota Bogor' ? 'selected' : ''); ?>>Kota Bogor</option>
                        <option value="Kota Cimahi" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kota Cimahi' ? 'selected' : ''); ?>>Kota Cimahi</option>
                        <option value="Kota Cirebon" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kota Cirebon' ? 'selected' : ''); ?>>Kota Cirebon</option>
                        <option value="Kota Depok" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kota Depok' ? 'selected' : ''); ?>>Kota Depok</option>
                        <option value="Kota Sukabumi" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kota Sukabumi' ? 'selected' : ''); ?>>Kota Sukabumi</option>
                        <option value="Kota Tasikmalaya" <?php echo e(old('inputKab', $entry['inputKab'] )== 'Kota Tasikmalaya' ? 'selected' : ''); ?>>Kota Tasikmalaya</option>
                    </select>
                </div>
                <div class="form-group col-4">
                    <label for="inputProv">Provinsi</label>
                    <input type="text" class="form-control" id="inputProv" name="inputProv" value="Jawa Barat" readonly="readonly">
                </div>
                <div class="form-group col-4">
                    <label for="inputNegara">Negara</label>
                    <input type="text" class="form-control" id="inputNegara" name="inputNegara" value="Indonesia" readonly="readonly">
                </div>
            </div>    
            <div class="form-row">
                <div class="form-group col-3">
                    <label for="inputTelp">Telepon</label>
                    <input type="text" class="form-control" id="inputTelp" name="inputTelp">
                </div>
                <div class="form-group col-3">
                    <label for="inputHP">No. HP</label>
                    <input type="text" class="form-control" id="inputHP" name="inputHP">
                </div>
                <div class="form-group col-6">
                    <label for="inputEmail">Email</label>
                    <input type="email" class="form-control" id="inputEmail" name="inputEmail" placeholder="Misal: abcdef@example.com">
                </div>
            </div>    
            <div class="form-row">
                <div class="form-group col-7">
                    <div class="form-row">
                        <div class="form-group col-4">
                            <label for="inputProf">Profesi</label>
                            <input type="text" class="form-control" id="inputProf" name="inputProf">
                        </div>
                        <div class="form-group col-4">
                            <label for="inputFB">Akun Facebook</label>
                            <input type="text" class="form-control" id="inputFB" name="inputFB">
                        </div>
                        <div class="form-group col-4">
                            <label for="inputIG">Akun Instagram</label>
                            <input type="text" class="form-control" id="inputIG" name="inputIG">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-6">
                            <label for="inputDona">Besaran Donasi</label>
                            <input type="number" class="form-control" id="inputDona" name="inputDona">
                        </div>
                        <div class="form-group col-6">
                            <label for="inputJenis">Jenis Donasi</label>
                            <select id="inputJenis" class="form-control" name="inputJenis">
                                <option value="Cash">Cash</option>
                                <option value="Transfer">Transfer</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="form-group col-5">
                    <div class="form-group col-12">
                        <label for="inputCatatan">Catatan</label>
                        <textarea style="min-height: 125px;" class="form-control" id="inputCatatan" name="inputCatatan" maxlength="150" placeholder="Maksimum 150 karakter..."></textarea>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Daftarkan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>