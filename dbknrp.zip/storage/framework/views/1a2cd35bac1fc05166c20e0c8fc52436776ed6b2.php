<?php $__env->startSection('pageTitle', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="header">
        <p>Selamat Datang, <?php echo e(Auth::user()->nama); ?></p>
    </div>

    <div>
        <ul class="nav nav-pills nav-fill">
            <?php if( Auth::user()->role === 2 || Auth::user()->role === 3 || Auth::user()->role === 4 ): ?>
            <li class="nav-item">
                <a class="nav-link" href="#">Input Donasi</a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
            <?php if( Auth::user()->role === 5): ?>
                <a class="nav-link <?php echo e(Request::segment(1) === 'data_donatur' ? 'active' : null); ?>" href="/data_donatur/<?php echo e(auth()->id()); ?>">Data Donatur</a>
            <?php else: ?>
                <a class="nav-link <?php echo e(Request::segment(1) === 'data_donatur' ? 'active' : null); ?>" href="<?php echo e(route ('dona_data')); ?>">Data Donatur</a>
            <?php endif; ?>
            </li>
            <li class="nav-item">
            <?php if( Auth::user()->role === 5): ?>
                <a class="nav-link <?php echo e(Request::segment(1) === 'riwayat_donasi' ? 'active' : null); ?>" href="/riwayat_donasi/<?php echo e(auth()->id()); ?>">Riwayat Donasi</a>
            <?php else: ?>
                <a class="nav-link <?php echo e(Request::segment(1) === 'riwayat_donasi' ? 'active' : null); ?>" href="<?php echo e(route('dona_riwa')); ?>">Riwayat Donasi</a>
            <?php endif; ?>
            </li>
            <?php if( Auth::user()->role === 5): ?>
            <?php else: ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::segment(1) === 'laporan' ? 'active' : null); ?>" href="<?php echo e(route('dona_laporan')); ?>">Laporan</a>
            </li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="card">
        <div style="padding:30px 10px;">
        <?php if(Route::current()->getName() == 'home'): ?>
            <p>Website ini masih dalam tahap pengembangan</p>
        <?php else: ?>
            <?php echo $__env->yieldContent('subcontent'); ?>
        <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>