<?php $__env->startSection('pageTitle', 'Data Donatur'); ?>

<?php $__env->startSection('subcontent'); ?>
<div class="container">
    <div class="card">
        <div class="card-header"><h4><?php echo e(__('PROFIL DONATUR')); ?></h4></div>
        <div class="card-body">
            <div class="row">
                <div class="col-4"><h5>ID Donatur: </h5></div>
                <div class="col-8"><?php echo e($donatur->user->no_id); ?></div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Tanggal Registrasi: </h5></div>
                <div class="col-8"><?php echo e($donatur->user->tgl_regis); ?></div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Nama Lengkap: </h5></div>
                <div class="col-8"><?php echo e($donatur->user->nama); ?></div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Tempat Lahir: </h5></div>
                <div class="col-8"><?php echo e($donatur->tempat_lahir); ?></div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Tanggal Lahir: </h5></div>
                <div class="col-8"><?php echo e($donatur->tgl_lahir); ?></div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Alamat Domisili: </h5></div>
                <div class="col-8"><?php echo e($donatur->alamat); ?> RT<?php echo e($donatur->rt); ?>/RW<?php echo e($donatur->rw); ?> <?php echo e($donatur->kelurahan); ?>, <?php echo e($donatur->kecamatan); ?>, <?php echo e($donatur->kota_kab); ?>, <?php echo e($donatur->provinsi); ?>, <?php echo e($donatur->negara); ?> <?php echo e($donatur->kodepos); ?></div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Telepon/No. HP: </h5></div>
                <div class="col-8"><?php echo e($donatur->no_telp); ?> / <?php echo e($donatur->no_hp); ?></div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Email: </h5></div>
                <div class="col-8"><?php echo e($donatur->email); ?></div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Facebook: </h5></div>
                <div class="col-8"><?php echo e($donatur->akun_facebook); ?></div>
            </div>
            <div class="row">
                <div class="col-4"><h5>Instagram: </h5></div>
                <div class="col-8"><?php echo e($donatur->akun_instagram); ?></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>