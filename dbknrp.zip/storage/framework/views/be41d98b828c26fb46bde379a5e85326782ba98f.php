<?php $__env->startSection('pageTitle', 'Riwayat Donasi'); ?>

<?php $__env->startSection('subcontent'); ?>
<div class="container">
    <form action="<?php echo e(url()->current()); ?>" style="padding: 0px 0px 10px 0px;">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="daerah">Daerah</label>
                <input type="text" class="form-control" id="daerah" placeholder="<?php echo e($donatur->kota_kab); ?>" disabled>
            </div>
            <div class="form-group col-md-2 offset-md-4">
                <label for="tahun">Tahun</label>
                <select id="tahun" class="form-control" name="keywordTahun">
                    <option selected value="">--- Semua ---</option>
                <?php for($i = 2018; $i<=2050; $i++): ?>
                    <option value="<?php echo e($i); ?>" <?php echo e(old('keywordTahun', $entry['keywordTahun'] )== $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="nama">Nama Lengkap</label>
                <input type="text" class="form-control" id="nama" placeholder="<?php echo e($donatur->user->nama); ?>" disabled>
            </div>
            <div class="form-group col-md-2 offset-md-4">
                <label for="bulan">Bulan</label>
                <select id="bulan" class="form-control" name="keywordBulan">
                <option value="">--- Semua ---</option>
                <option value="1" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '1' ? 'selected' : ''); ?>>01 - Januari</option>
                <option value="2" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '2' ? 'selected' : ''); ?>>02 - Februari</option>
                <option value="3" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '3' ? 'selected' : ''); ?>>03 - Maret</option>
                <option value="4" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '4' ? 'selected' : ''); ?>>04 - April</option>
                <option value="5" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '5' ? 'selected' : ''); ?>>05 - Mei</option>
                <option value="6" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '6' ? 'selected' : ''); ?>>06 - Juni</option>
                <option value="7" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '7' ? 'selected' : ''); ?>>07 - Juli</option>
                <option value="8" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '8' ? 'selected' : ''); ?>>08 - Agustus</option>
                <option value="9" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '9' ? 'selected' : ''); ?>>09 - September</option>
                <option value="10" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '10' ? 'selected' : ''); ?>>10 - Oktober</option>
                <option value="11" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '11' ? 'selected' : ''); ?>>11 - November</option>
                <option value="12" <?php echo e(old('keywordBulan', $entry['keywordBulan'] )== '12' ? 'selected' : ''); ?>>12 - Desember</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-primary offset-md-10">Cari sesuai filter</button>
    </form>
    <div class="row">
        <table class="table table-striped" id="tabel_data">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Jumlah Donasi</th>
                    <th>Cash/Transfer</th>
                    <th>Bank</th>
                    <th>Petugas</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($riwa->tanggal); ?></td>
                    <td><?php echo 'Rp' . number_format($riwa->dona_jml,2,',','.'); ?></td>
                    <td><?php echo e($riwa->dona_jenis); ?></td>
                    <td><?php echo e($riwa->bank); ?></td>
                    <td><?php echo e($riwa->bank_petugas); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <center><?php echo e($riwayat->links()); ?></center>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>